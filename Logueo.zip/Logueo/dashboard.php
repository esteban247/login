<?php

require('db.php');
include("auth.php"); //incluir el archivo auth.php en todas las páginas seguras?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Pagina de seguridad</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Dashboard</p>
<p>Esta es otra pagina de seguridad.</p>
<p><a href="index.php">Home</a></p>
<a href="logout.php">Salir</a>


<br /><br /><br /><br />
</div>
</body>
</html>
