<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Iniciar Sesion</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
	require('db.php');
	session_start();
    // Si se envió el formulario, inserte los valores en la base de datos.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // elimina las barras diagonales inversas
		$username = mysqli_real_escape_string($con,$username); //escapa de los caracteres especiales en una cadena
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Verificar si el usuario existe en la base de datos o no
        $query = "SELECT * FROM `users` WHERE username='$username' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: index.php"); // Redirigir al usuario a index.php
            }else{
				echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
<div class="form">
<h1>Iniciar sesion</h1>
<form action="" method="post" name="login">
<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input name="submit" type="submit" value="Login" />
</form>
<p>Usuario no registrado <a href='registration.php'>Registrate aquí</a></p>

<br /><br />
</div>
<?php } ?>


</body>
</html>
